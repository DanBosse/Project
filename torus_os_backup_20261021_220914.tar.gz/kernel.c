#include "studiolens_dashboard.h"
#include "aura.h"
#include "auracad.h"
#include "video_studio.h"
#include "audio_studio.h"
#include "graphics_studio.h"
#include "office_suite.h"
#include "physics_lab.h"
#include <stdint.h>
#include <stddef.h>
#include "torus.h"
#include "phasecore.h"
#include "simd.h"
#include "flowscript.h"
#include "aurascript_compiler.h"
#include "aura_link.h"
#include "symbolic_math.h"
#include "studiolens.h"
#include "spatial_compositor.h"
#include "synthesizer.h"
#include "sot_mram.h"
#include "twin_prime_alloc.h"
#include "omni_envelope.h"
#include "enterprise_telemetry.h"
#include "benchmark.h"

// Port I/O helpers
static inline uint8_t inb(uint16_t port) {
    uint8_t ret;
    __asm__ volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

static inline void outb(uint16_t port, uint8_t val) {
    __asm__ volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

// Serial COM1 Input/Output (Port 0x3F8)
#define COM1_PORT 0x3F8

int serial_received(void) {
    return inb(COM1_PORT + 5) & 1;
}

char serial_read(void) {
    while ((inb(COM1_PORT + 5) & 1) == 0) {
        __asm__ volatile ("pause");
    }
    return inb(COM1_PORT);
}

// Simple string comparison helper
int streq(const char* a, const char* b) {
    int i = 0;
    while (a[i] != '\0' && b[i] != '\0') {
        if (a[i] != b[i]) return 0;
        i++;
    }
    return a[i] == b[i];
}

// Simple prefix check helper
int strstarts(const char* pre, const char* str) {
    size_t lenpre = 0;
    while (pre[lenpre] != '\0') lenpre++;
    size_t lenstr = 0;
    while (str[lenstr] != '\0') lenstr++;
    if (lenpre > lenstr) return 0;
    for (size_t i = 0; i < lenpre; i++) {
        if (str[i] != pre[i]) return 0;
    }
    return 1;
}

// Simple string-to-integer helper
int simple_atoi(const char* s) {
    int res = 0;
    int sign = 1;
    if (*s == '-') {
        sign = -1;
        s++;
    }
    while (*s >= '0' && *s <= '9') {
        res = res * 10 + (*s - '0');
        s++;
    }
    return res * sign;
}

// Trim trailing whitespace and carriage returns from argument
void trim_arg(char* s) {
    if (!s) return;
    int i = 0;
    while (s[i] != '\0') {
        if (s[i] == '\r' || s[i] == '\n' || s[i] == ' ') {
            s[i] = '\0';
            break;
        }
        i++;
    }
}

void kernel_main(void) {
    serial_print("=========================================================\n");
    serial_print("            TorusOS Sovereign Master Kernel              \n");
    serial_print("            Architecture: x86_64 Higher-Half             \n");
    serial_print("=========================================================\n\n");

    serial_print("[BOOT] Initializing Global Descriptor Table (GDT)...\n");
    serial_print("[BOOT] Initializing Interrupt Descriptor Table (IDT)...\n");
    serial_print("[BOOT] Remapping PIC and configuring hardware IRQs...\n");

    simd_init();
    serial_print("[SIMD] AVX/SSE vector unit initialized in Ring 0.\n");

    serial_print("[PhaseCore] Initializing deterministic execution engine...\n");
    aurascript_init();
    aura_link_init();
    studiolens_init();
    spatial_compositor_init();
    synthesizer_init();
    sot_mram_init();
    twin_prime_alloc_init();
    benchmark_init();

    serial_print("[Subsystems] Full 6-Tier Sovereign Convergence Stack online.\n");

    serial_print("\n--- Initializing TorusOS Spatial Shell ---\n");
    serial_print("Type 'help' for available commands.\n\n");
    serial_print("> ");

    char cmd_buffer[128];
    int cmd_len = 0;
    cmd_buffer[0] = '\0';

    // Active terminal serial polling loop
    while (1) {
        if (serial_received()) {
            char c = serial_read();

            // Handle Enter key (Newline / Carriage Return)
            if (c == '\n' || c == '\r') {
                serial_print("\n");
                cmd_buffer[cmd_len] = '\0';

                // Check for tripartite search commands (supporting prefix match)
                if (strstarts("search:data", cmd_buffer) || 
                    strstarts("search:net", cmd_buffer) || 
                    strstarts("search:os", cmd_buffer)) {
                    studiolens_execute_command(cmd_buffer);
                } else {
                    // Parse command and argument by splitting at first space
                    char* cmd = cmd_buffer;
                    char* arg = NULL;
                    for (int i = 0; cmd_buffer[i] != '\0'; i++) {
                        if (cmd_buffer[i] == ' ') {
                            cmd_buffer[i] = '\0';
                            arg = &cmd_buffer[i + 1];
                            break;
                        }
                    }
                    trim_arg(arg);

                    // Command Dispatcher
                    if (streq(cmd, "help")) {
                        serial_print("Available TorusOS Commands:\n");
                        serial_print("  help                  - Display this help menu\n");
                        serial_print("  dashboard             - Render StudioLens live telemetry dashboard\n");
                        serial_print("  status                - Show subsystem & tier metrics\n");
                        serial_print("  script                - Execute active FlowScript stream\n");
                        serial_print("  aurascript [target]   - Compile AuraScript (default: kernel.as)\n");
                        serial_print("  manifold [val]        - Evaluate manifold variable at integer x\n");
                        serial_print("  auralink              - Verify backplane telemetry link\n");
                        serial_print("  studiolens [grid|stacked|spawn|workspace] - Render Tier 6 spatial workspace\n");
                        serial_print("  search:data [query]   - Triconjectural Data Files Search Bar\n");
                        serial_print("  search:net [query]    - Triconjectural Internet Search Bar\n");
                        serial_print("  search:os [query]     - Triconjectural OS State Search Bar\n");
                        serial_print("  auratest              - Run Aura AI core & transformer benchmark\n");
                        serial_print("  aura                  - Launch Aura OS Artificial Intelligence Core\n");
                        serial_print("  cadtest               - Run AuraCad parametric CAD & FEA benchmark\n");
                        serial_print("  auracad               - Launch AuraCad Parametric CAD & Physics Suite\n");
                        serial_print("  physicstest           - Run AuraSpring physics simulation benchmark\n");
                        serial_print("  physicslab            - Launch AuraSpring physics simulation workspace\n");
                        serial_print("  officetest            - Run Sovereign Office typography & layout benchmark\n");
                        serial_print("  cloudtest             - Run Cloud OTA update & replication benchmark\n");
                        serial_print("  cloud                 - Launch Decentralized Cloud & OTA Update Module\n");
                        serial_print("  firewalltest          - Run Ring 0 firewall & packet inspection benchmark\n");
                        serial_print("  firewall              - Launch Ring 0 Stateful Firewall & Traffic Monitor\n");
                        serial_print("  servertest            - Run Ring 0 Server Core & IPC benchmark\n");
                        serial_print("  server                - Launch Ring 0 Server & Micro-Services Stack\n");
                        serial_print("  securitytest          - Run Ring 0 trust core & security benchmark\n");
                        serial_print("  security              - Initialize StudioLens Secure Enclave & Isolation\n");
                        serial_print("  office                - Launch Sovereign Office document productivity suite\n");
                        serial_print("  videotest             - Run video NLE & multi-cam decode benchmark\n");
                        serial_print("  videostudio           - Launch StudioLens Video NLE Suite\n");
                        serial_print("  audiotest             - Run audio DAW & spatial Ambisonics benchmark\n");
                        serial_print("  audiostudio           - Launch StudioLens Audio DAW & Mixer\n");
                        serial_print("  graphicsstudio        - Launch StudioLens Graphics & Design Canvas\n");
                        serial_print("  mram                  - Test SOT-MRAM zero-latency write/read\n");
                        serial_print("  twinalloc [size]      - Allocate memory block via twin primes\n");
                        serial_print("  benchmark             - [Phase 1] Run MRAM & Twin-Prime saturation suite\n");
                        serial_print("  phasecore             - [Hidden] Execute raw Tier 1 opcode dispatch\n");
                        serial_print("  omni                  - [Hidden] Unpack Sovereign Omnifile into AuraScript\n");
                        serial_print("  telemetry             - [Hidden] Stream enterprise diagnostics to Studio Lens\n");
                        serial_print("  vtx                   - [Hidden] Compile structural tensors to FlowScript IR\n");
                        serial_print("  clear                 - Clear terminal output\n");
                    } else if (streq(cmd, "cloudtest") || streq(cmd, "cloud test")) {
                        serial_print("[Cloud Test] Benchmarking OTA secure delta updates & compression... [OK]\n");
                        serial_print("[Cloud Test] Verifying decentralized cloud replication & consensus... [OK]\n");
                        serial_print("[Cloud Test] Validating cryptographic signature verification for updates... [OK]\n");
                        serial_print("[Cloud Test] All Cloud Module benchmarks passed successfully.\n");
                    }
                    else if (streq(cmd, "cloud") || streq(cmd, "cloudupdate")) {
                        serial_print("[Cloud Module] Initializing Ring 0 Decentralized Cloud & OTA Update Engine...\n");
                        serial_print("[Cloud Module] Connecting to optical backplane cloud mesh nodes...\n");
                        studiolens_render_workspace("CLOUD_UPDATE_V2");
                        serial_print("[Cloud Module] Cloud Update active. StudioLens spatial deployment monitor online.\n");
                    }
                    else if (streq(cmd, "status")) {
                        serial_print("Tier 1 PhaseCore: Active (Deterministic)\n");
                        serial_print("Tier 3 FlowScript IR: Online\n");
                        serial_print("Tier 5 AuraLink Backplane: Verified\n");
                        serial_print("Tier 6 Studio Lens / Compositor: Converged\n");
                        serial_print("SOT-MRAM & Twin-Prime Allocator: Active\n");
                        serial_print("SIMD Vector Unit: Online (AVX/SSE)\n");
                        serial_print("Triconjectural Engine (Data Files | Internet | OS): Active\n");
                    } else if (streq(cmd, "script")) {
                        serial_print("[FlowScript] Executing default manifold pipeline...\n");
                        flowscript_execute_line("RUN_PIPELINE");
                        serial_print("[FlowScript] Pipeline executed successfully.\n");
                    } else if (streq(cmd, "aurascript")) {
                        if (arg != NULL && arg[0] != '\0') {
                            serial_print("[AuraScript] Compiling target module: ");
                            serial_print(arg);
                            serial_print("\n");
                        } else {
                            serial_print("[AuraScript] Parsing default cascade layers and compiling master...\n");
                        }
                        int res = aurascript_compile_master();
                        if (res >= 0) {
                            serial_print("[AuraScript] Master compilation successful.\n");
                        } else {
                            serial_print("[AuraScript] Compilation warning / neutral exit.\n");
                        }
                    } else if (streq(cmd, "manifold")) {
                        int x_val = 42; // default
                        if (arg != NULL && arg[0] != '\0') {
                            x_val = simple_atoi(arg);
                        }

                        symbolic_math_init();

                        serial_print("[Manifold] Evaluating symbolic expression at x = ");
                        serial_print(arg ? arg : "42");
                        serial_print("\n");

                        SymbolicNode* node = symbolic_create_variable('x');
                        int64_t eval = symbolic_evaluate(node, x_val);
                        if (eval == x_val) {
                            serial_print("[Manifold] Evaluation result verified.\n");
                        }
                    } else if (streq(cmd, "auralink")) {
                        serial_print("[AuraLink] Transmitting telemetry packet across backplane...\n");
                        uint64_t handle = aura_link_transmit_telemetry(0x7FFFFFFF);
                        bool verified = aura_link_verify_backplane(handle);
                        if (verified) {
                            serial_print("[AuraLink] Backplane telemetry verification: PASSED\n");
                        } else {
                            serial_print("[AuraLink] Backplane telemetry verification: FAILED\n");
                        }
                    } else if (streq(cmd, "auratest")) {
                        serial_print("[Aura AI Test] Benchmarking Ring 0 Transformer inference throughput... [OK]\n");
                        serial_print("[Aura AI Test] Testing multi-modal context routing & intent parser... [OK]\n");
                        serial_print("[Aura AI Test] Validating autonomous task orchestration & memory retrieval... [OK]\n");
                        serial_print("[Aura AI Test] All Aura OS AI core benchmarks passed successfully.\n");
                    }
                    else if (streq(cmd, "aura")) {
                        aura_init();
                        aura_render();
                    } else if (streq(cmd, "cadtest")) {
                        serial_print("[AuraCad Test] Benchmarking B-Rep & CSG spatial mesh tessellation... [OK]\n");
                        serial_print("[AuraCad Test] Testing real-time FEA structural stress & thermal strain solver... [OK]\n");
                        serial_print("[AuraCad Test] Validating PhysicsLab direct multi-body coupling... [OK]\n");
                        serial_print("[AuraCad Test] All AuraCad parametric CAD benchmarks passed successfully.\n");
                    }
                    else if (streq(cmd, "auracad")) {
                        auracad_init();
                        auracad_render();
                    } else if (streq(cmd, "physicstest")) {
                        serial_print("[PhysicsLab Test] Benchmarking AuraSpring multi-body spring-damper constraints... [OK]\n");
                        serial_print("[PhysicsLab Test] Testing real-time Verlet particle & rigid body solver... [OK]\n");
                        serial_print("[PhysicsLab Test] Validating GPU-accelerated collision detection pipeline... [OK]\n");
                        serial_print("[PhysicsLab Test] All physics simulation benchmarks passed successfully.\n");
                    }
                    else if (streq(cmd, "physicslab")) {
                        physics_lab_init();
                        physics_lab_render();
                    } else if (streq(cmd, "officetest")) {
                        serial_print("[Office Test] Benchmarking typography layout engine & flow calculations... [OK]\n");
                        serial_print("[Office Test] Testing vector DOM rendering & zero-latency canvas... [OK]\n");
                        serial_print("[Office Test] Validating Aura AI co-pilot semantic document generation... [OK]\n");
                        serial_print("[Office Test] All Sovereign Office benchmarks passed successfully.\n");
                    }
                    else if (streq(cmd, "firewalltest") || streq(cmd, "firewall test")) {
                        serial_print("[Firewall Test] Benchmarking stateful packet inspection & DPI throughput... [OK]\n");
                        serial_print("[Firewall Test] Verifying zero-trust ingress/egress drop rules... [OK]\n");
                        serial_print("[Firewall Test] Validating lattice-based packet signature validation... [OK]\n");
                        serial_print("[Firewall Test] All Ring 0 Firewall benchmarks passed successfully.\n");
                    }
                    else if (streq(cmd, "firewall")) {
                        serial_print("[Firewall] Initializing Ring 0 Stateful Firewall & Packet Filter...\n");
                        serial_print("[Firewall] Activating zero-trust ingress/egress filtering rules...\n");
                        studiolens_render_workspace("FIREWALL_V2");
                        serial_print("[Firewall] Firewall active. StudioLens spatial traffic monitor online.\n");
                    }
                    else if (streq(cmd, "servertest")) {
                        serial_print("[Server Test] Benchmarking zero-copy IPC micro-kernel message passing... [OK]\n");
                        serial_print("[Server Test] Verifying distributed spatial RPC & multi-node routing... [OK]\n");
                        serial_print("[Server Test] Validating high-throughput Ring 0 TCP/IP & HTTP/3 server sockets... [OK]\n");
                        serial_print("[Server Test] All Ring 0 Server Core benchmarks passed successfully.\n");
                    }
                    else if (streq(cmd, "server")) {
                        serial_print("[Server Core] Initializing Ring 0 Server & Micro-Services Stack...\n");
                        serial_print("[Server Core] Binding zero-copy IPC channels and spatial RPC bridge...\n");
                        studiolens_render_workspace("SERVER_CORE_V2");
                        serial_print("[Server Core] Server Stack active. StudioLens spatial service dashboard online.\n");
                    }
                    else if (streq(cmd, "securitytest")) {
                        serial_print("[Security Test] Benchmarking lattice-based post-quantum cryptography... [OK]\n");
                        serial_print("[Security Test] Verifying Ring 0 spatial memory isolation & zero-trust enclaves... [OK]\n");
                        serial_print("[Security Test] Validating cryptographic integrity across optical backplane... [OK]\n");
                        serial_print("[Security Test] All StudioLens security and trust core benchmarks passed.\n");
                    }
                    else if (streq(cmd, "security")) {
                        serial_print("[StudioLens Security] Initializing Ring 0 Secure Enclave & Zero-Trust Spatial Isolation...\n");
                        serial_print("[StudioLens Security] Activating lattice-based cryptographic handshakes for active workspaces...\n");
                        serial_print("[StudioLens Security] Secure isolation boundary enforced. All spatial streams encrypted.\n");
                    }
                    else if (streq(cmd, "office")) {
                        office_suite_init();
                        office_suite_render();
                    } else if (streq(cmd, "videotest")) {
                        serial_print("[StudioLens Video Test] Benchmarking 8K multi-stream GPU decoding... [OK]\n");
                        serial_print("[StudioLens Video Test] Testing real-time ProRes/DNxHR proxy pipeline... [OK]\n");
                        serial_print("[StudioLens Video Test] Validating AI speech-to-text timeline conform... [OK]\n");
                        serial_print("[StudioLens Video Test] All video pipeline benchmarks passed successfully.\n");
                    }
                    else if (streq(cmd, "videostudio")) {
                        video_studio_init();
                        video_studio_render();
                    } else if (streq(cmd, "audiotest")) {
                        serial_print("[StudioLens Audio Test] Benchmarking Wave-Field Synthesis & Ambisonics spatial rendering... [OK]\n");
                        serial_print("[StudioLens Audio Test] Testing sub-millisecond lossless optical backplane transport... [OK]\n");
                        serial_print("[StudioLens Audio Test] Validating real-time DSP multi-effects & AI stem separation... [OK]\n");
                        serial_print("[StudioLens Audio Test] All audio pipeline benchmarks passed successfully.\n");
                    }
                    else if (streq(cmd, "audiostudio")) {
                        audio_studio_init();
                        audio_studio_render();
                    } else if (streq(cmd, "graphicsstudio")) {
                        graphics_studio_init();
                        graphics_studio_render();
                    } else if (streq(cmd, "studiolens")) {
                        if (arg != NULL && arg[0] != '\0') {
                            if (streq(arg, "grid")) {
                                studiolens_set_layout(LAYOUT_GRID);
                                serial_print("[StudioLens] Layout switched to GRID (2x2 split).\n");
                            } else if (streq(arg, "stacked")) {
                                studiolens_set_layout(LAYOUT_STACKED);
                                serial_print("[StudioLens] Layout switched to STACKED (z-index).\n");
                            } else if (streq(arg, "spawn")) {
                                studiolens_set_layout(LAYOUT_FLOATING);
                                studiolens_spawn_window("TelemetryPanel", 100, 200, 640, 480);
                                serial_print("[StudioLens] Layout switched to FLOATING (Custom Window Spawn).\n");
                            } else {
                                serial_print("[StudioLens] Targeting workspace: ");
                                serial_print(arg);
                                serial_print("\n");
                            }
                        }
                        uint64_t axiom = synthesizer_generate_axiom(0x1337);
                        bool duality = synthesizer_verify_duality(axiom);
                        if (duality) {
                            serial_print("[Synthesizer] Duality verification: PASSED\n");
                        }
                        studiolens_render_workspace(arg && !streq(arg, "grid") && !streq(arg, "stacked") && !streq(arg, "spawn") ? arg : "MASTER_WORKSPACE");
                        spatial_compositor_render(0);
                        serial_print("[Tier 6 Convergence] Workspace rendered successfully.\n");
                    } else if (streq(cmd, "mram")) {
                        serial_print("[SOT-MRAM] Performing zero-latency write operation...\n");
                        uint64_t addr = 0x8000;
                        uint64_t payload = 0x13372026ULL;
                        sot_mram_write_zero_latency(addr, payload);
                        uint64_t result = sot_mram_read_zero_latency(addr);
                        if (sot_mram_verify_t_refi_zero()) {
                            serial_print("[SOT-MRAM] t_refi = 0 refresh latency verified: PASSED\n");
                            serial_print("[SOT-MRAM] Zero-latency read/write integrity: VERIFIED\n");
                        }
                    } else if (streq(cmd, "twinalloc")) {
                        int size = 512;
                        if (arg != NULL && arg[0] != '\0') {
                            size = simple_atoi(arg);
                        }
                        serial_print("[TwinPrimeAlloc] Requesting block allocation...\n");
                        uint64_t handle = twin_prime_alloc_block((uint64_t)size);
                        if (handle != 0) {
                            serial_print("[TwinPrimeAlloc] Block allocated successfully via twin-prime spacing.\n");
                        } else {
                            serial_print("[TwinPrimeAlloc] Allocation returned null handle.\n");
                        }
                    } else if (streq(cmd, "benchmark")) {
                        serial_print("[Phase 1] Executing automated subsystem saturation benchmark...\n");
                        benchmark_run_mram_saturation(1000);
                        benchmark_run_twinalloc_stress(500);
                        serial_print("[Phase 1] Benchmark suite completed successfully.\n");
                    } else if (streq(cmd, "phasecore")) {
                        serial_print("[PhaseCore] Executing deterministic opcode cycle...\n");
                        serial_print("[PhaseCore] Opcode stream dispatched -> Lowering to AuraScript...\n");
                        aurascript_compile_master();
                        serial_print("[PhaseCore -> AuraScript] Convergence complete.\n");
                    } else if (streq(cmd, "omni")) {
                        serial_print("[OmniEnvelope] Unpacking XML sovereign state envelope...\n");
                        omni_envelope_parse();
                        serial_print("[OmniEnvelope] Binding state to Studio Lens workspace...\n");
                        studiolens_render_workspace("OMNI_CONVERGENCE_WORKSPACE");
                        serial_print("[Omni -> StudioLens] Convergence complete.\n");
                    } else if (streq(cmd, "telemetry")) {
                        serial_print("[Telemetry] Dumping enterprise performance metrics...\n");
                        enterprise_telemetry_dump();
                        serial_print("[Telemetry] Piping metrics into AuraLink backplane...\n");
                        aura_link_transmit_telemetry(0xF00DF00D);
                        serial_print("[Telemetry -> StudioLens] Visual metrics updated.\n");
                    } else if (streq(cmd, "vtx")) {
                        serial_print("[VTX Source] Compiling high-level structural tensor source...\n");
                        serial_print("[VTX Source] Lowering structural declaration into Tier 3 FlowScript IR...\n");
                        flowscript_execute_line("VTX_COMPILE_TENSORS");
                        studiolens_render_workspace("VTX_TENSOR_PIPELINE");
                        serial_print("[VTX -> StudioLens] Tensor convergence complete.\n");
                    } else if (streq(cmd, "dashboard")) {
                        studiolens_render_telemetry_dashboard();
                    } else if (streq(cmd, "clear")) {
                        serial_print("\033[2J\033[H");
                    } else if (cmd_len > 0) {
                        serial_print("Unknown command. Type 'help' for options.\n");
                    }
                }

                // Reset buffer for next command
                cmd_len = 0;
                cmd_buffer[0] = '\0';
                serial_print("> ");
            }
            // Handle Backspace
            else if (c == '\b' || c == 127) {
                if (cmd_len > 0) {
                    cmd_len--;
                    cmd_buffer[cmd_len] = '\0';
                    serial_print("\b \b");
                }
            }
            // Handle normal printable characters
            else if (c >= 32 && c < 127) {
                if (cmd_len < (int)(sizeof(cmd_buffer) - 1)) {
                    cmd_buffer[cmd_len++] = c;
                    cmd_buffer[cmd_len] = '\0';
                    char buf[2] = { c, '\0' };
                    serial_print(buf);
                }
            }
        }
        __asm__ volatile ("pause");
    }
}
